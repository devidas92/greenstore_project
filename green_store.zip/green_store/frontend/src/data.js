export default {
    products:[ 
        { 
        "name":"Potato", 
        "id":1, 
        "price":30, 
        "available":1, 
        "vendor":"Himachal Pvt Ltd", 
        "category":"Vegtables",
        "image":"/images/p1.jpg"
        }, 
        { 
        "name":"Banana", 
        "id":2, 
        "price":50, 
        "available":1, 
        "category":"Fruits",
        "vendor": "Organic farms",
        "image":"/images/banana.jpg"
        
        }, 
        { 
        "name":"Drumsticks", 
        "id":3, 
        "price":20, 
        "available":0, 
        "category":"Vegetables", 
        "vendor":"Mallikarjuna farms",
        "image":"/images/drumstick.jpg"
        }, 
        { 
        "name":"Orange", 
        "id":4, 
        "price":25, 
        "available":1, 
        "vendor":"Nagpur farms", 
        "category":"Fruits",
        "image":"/images/hju.jpg"
        } 
        ] 
        
}